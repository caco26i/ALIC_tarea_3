se ocupa numpy
y python 2.7.11